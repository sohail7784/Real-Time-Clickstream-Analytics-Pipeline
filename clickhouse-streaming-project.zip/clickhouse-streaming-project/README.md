# ClickHouse End-to-End: Real-Time Ingestion Program
### **Kafka → ClickHouse → Grafana (Chapters 291–300)**

This program provides a production-grade, self-contained streaming pipeline. It demonstrates how to handle high-velocity event data using Kafka as a durable shock absorber, ClickHouse for sub-second analytics, and Grafana for operational observability.

## 🏗️ Architecture Overview

The pipeline follows a **Medallion-inspired Architecture** within ClickHouse:
1.  **Producer Tier:** Python script generating high-cardinality JSON clickstream events.
2.  **Buffer Tier:** Kafka (6 partitions) ensuring durability and handling backpressure.
3.  **Bronze Layer:** ClickHouse `Kafka` Engine subscribing to topics and parsing JSON.
4.  **Silver Layer:** Materialized Views transforming and moving data to `ReplacingMergeTree` storage.
5.  **Gold Layer:** `AggregatingMergeTree` providing pre-calculated real-time business metrics for dashboards.



---

## 🚀 Quick Start

### 1. Prerequisites
* **Docker & Docker Compose**
* **Python 3.9+**
* **ClickHouse Client** (Optional, for local CLI access)

### 2. Bootstrap the Environment
Run the master setup script to orchestrate the infrastructure, Kafka topics, and ClickHouse schemas in the correct order:
```bash
chmod +x setup.sh
./setup.sh