-- 1. Drop the old queue
DROP TABLE IF EXISTS default.kafka_web_events_queue;

-- 2. Create the new queue pointing to the internal listener
CREATE TABLE default.kafka_web_events_queue
(
    event_time String,
    user_id UInt64,
    session_id String,
    action String,
    device String,
    product_id UInt32,
    amount Float64
)
ENGINE = Kafka
SETTINGS 
    kafka_broker_list = 'clickhouse-streaming-kafka-1:29092',
    kafka_topic_list = 'web_events',
    kafka_group_name = 'ch_ingestion_group_v3', -- New group to start fresh
    kafka_format = 'JSONEachRow',
    kafka_num_consumers = 1;
	
	
CREATE TABLE default.web_events_final
(
    event_date Date DEFAULT toDate(event_time),
    event_time DateTime,
    user_id UInt64,
    session_id String,
    action LowCardinality(String),
    device LowCardinality(String),
    product_id UInt32,
    amount Float64
)
ENGINE = ReplacingMergeTree()
PARTITION BY event_date
ORDER BY (event_date, action, user_id, session_id);


CREATE TABLE default.web_events_hourly_summary
(
    event_hour DateTime,
    product_id UInt32,
    total_revenue AggregateFunction(sum, Float64),
    event_count AggregateFunction(count, UInt64)
)
ENGINE = AggregatingMergeTree()
ORDER BY (event_hour, product_id);
