CREATE MATERIALIZED VIEW IF NOT EXISTS default.web_events_consumer
TO default.web_events_final
AS
SELECT
    parseDateTimeBestEffort(event_time) AS event_time,
    user_id,
    session_id,
    action,
    device,
    product_id,
    amount
FROM default.kafka_web_events_queue;


CREATE MATERIALIZED VIEW IF NOT EXISTS default.hourly_stats_mv
TO default.hourly_stats_mv_storage
AS
SELECT
    toStartOfHour(event_time) AS event_hour,
    action,
    sum(amount) AS total_sales,
    count() AS event_count,
    uniqState(user_id) AS unique_users
FROM default.web_events_final
GROUP BY event_hour, action;

CREATE MATERIALIZED VIEW default.web_events_mv TO default.web_events_final AS
SELECT
    parseDateTimeBestEffort(event_time) AS event_time,
    user_id,
    session_id,
    action,
    device,
    product_id,
    amount
FROM default.kafka_web_events_queue;


CREATE MATERIALIZED VIEW default.web_events_hourly_mv TO default.web_events_hourly_summary AS
SELECT
    toStartOfHour(event_time) AS event_hour,
    product_id,
    sumState(amount) AS total_revenue,
    countState() AS event_count
FROM default.web_events_final
GROUP BY event_hour, product_id;