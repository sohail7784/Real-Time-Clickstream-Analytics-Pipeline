CREATE TABLE IF NOT EXISTS default.hourly_stats_mv_storage
(
    event_hour DateTime,
    action LowCardinality(String),
    total_sales SimpleAggregateFunction(sum, Float64),
    event_count SimpleAggregateFunction(count, UInt64),
    unique_users AggregateFunction(uniq, UInt64)
)
ENGINE = AggregatingMergeTree()
ORDER BY (event_hour, action);