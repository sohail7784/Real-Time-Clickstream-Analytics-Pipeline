-- Expert Query: Instant results regardless of data size
SELECT
    event_hour,
    action,
    total_sales,
    event_count,
    uniqMerge(unique_users) AS daily_uniques
FROM default.hourly_stats_mv_storage
WHERE event_hour >= now() - INTERVAL 24 HOUR
GROUP BY event_hour, action, total_sales, event_count;

SELECT
    event_hour,
    product_id,
    sumMerge(total_revenue) AS revenue,
    countMerge(event_count) AS events
FROM default.web_events_hourly_summary
GROUP BY event_hour, product_id
ORDER BY event_hour DESC;