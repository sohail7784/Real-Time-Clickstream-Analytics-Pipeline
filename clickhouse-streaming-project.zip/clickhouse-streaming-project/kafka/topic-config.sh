#!/bin/bash

# Configuration Variables
BOOTSTRAP_SERVER="localhost:9092"
TOPIC_NAME="web_events"
PARTITIONS=6
REPLICATION_FACTOR=1 # Set to 3 in a real production cluster
RETENTION_MS=604800000 # 7 Days in milliseconds

echo "--- Kafka Topic Configuration Manager ---"

# 1. Check if the topic exists
TOPIC_EXISTS=$(docker exec clickhouse-streaming-kafka-1 kafka-topics.sh --bootstrap-server $BOOTSTRAP_SERVER --list | grep -w "$TOPIC_NAME")

if [ -z "$TOPIC_EXISTS" ]; then
    echo "Creating topic: $TOPIC_NAME..."
    docker exec clickhouse-streaming-kafka-1 kafka-topics.sh --bootstrap-server $BOOTSTRAP_SERVER \
        --create --topic $TOPIC_NAME \
        --partitions $PARTITIONS \
        --replication-factor $REPLICATION_FACTOR \
        --config retention.ms=$RETENTION_MS \
        --config compression.type=snappy
else
    echo "Topic '$TOPIC_NAME' already exists. Applying expert tuning..."
    
    # Increase partitions if needed (Scaling Chapter 299)
    docker exec clickhouse-streaming-kafka-1 kafka-topics.sh --bootstrap-server $BOOTSTRAP_SERVER \
        --alter --topic $TOPIC_NAME --partitions $PARTITIONS
    
    # Update Retention and Segment settings
    docker exec clickhouse-streaming-kafka-1 kafka-configs.sh --bootstrap-server $BOOTSTRAP_SERVER \
        --entity-type topics --entity-name $TOPIC_NAME --alter \
        --add-config retention.ms=$RETENTION_MS,segment.bytes=1073741824,max.message.bytes=1048576
fi

echo "Current Configuration for $TOPIC_NAME:"
docker exec clickhouse-streaming-kafka-1 kafka-topics.sh --bootstrap-server $BOOTSTRAP_SERVER --describe --topic $TOPIC_NAME