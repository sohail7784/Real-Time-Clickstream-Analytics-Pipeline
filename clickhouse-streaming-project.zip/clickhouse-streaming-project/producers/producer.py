import json
import random
import time
from datetime import datetime
from confluent_kafka import Producer

# Configuration for local Kafka (from Chapter 291)
conf = {
    'bootstrap.servers': 'localhost:9092',
    'client.id': 'clickstream-producer',
    'linger.ms': 100,      # Batching for throughput
    'compression.type': 'snappy' # Expert tip: always compress at the source
}

producer = Producer(conf)
TOPIC = 'web_events'

def delivery_report(err, msg):
    """ Callback for asynchronous write confirmation """
    if err is not None:
        print(f"Message delivery failed: {err}")
    else:
        pass # Successful delivery

def generate_event():
    """ Creates a realistic e-commerce click event """
    actions = ['view', 'add_to_cart', 'checkout', 'search']
    devices = ['mobile', 'desktop', 'tablet']
    
    return {
        'event_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
        'user_id': random.randint(1000, 9999),
        'session_id': f"sess_{random.randint(1, 100000)}",
        'action': random.choice(actions),
        'device': random.choice(devices),
        'product_id': random.randint(1, 500),
        'amount': round(random.uniform(10.0, 500.0), 2)
    }

print("🚀 Starting Stream Generation... Press Ctrl+C to stop.")

try:
    while True:
        event = generate_event()
        # Triggering the produce (Asynchronous)
        producer.produce(
            TOPIC, 
            key=str(event['user_id']), 
            value=json.dumps(event).encode('utf-8'),
            callback=delivery_report
        )
        
        # Poll ensures callbacks are served
        producer.poll(0)
        
        # Simulate ~100 events per second
        time.sleep(0.01) 

except KeyboardInterrupt:
    print("Stopping producer...")
finally:
    # Flush ensures all messages in the buffer are sent before exit
    producer.flush()