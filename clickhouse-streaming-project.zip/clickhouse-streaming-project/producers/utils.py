import random
import uuid
from datetime import datetime

class DataFactory:
    """Helper class to generate realistic clickstream data."""
    
    def __init__(self):
        self.actions = ['view', 'add_to_cart', 'checkout', 'search', 'remove_from_cart']
        self.devices = ['mobile', 'desktop', 'tablet', 'smart_tv']
        self.os = {
            'mobile': ['iOS', 'Android'],
            'desktop': ['Windows', 'macOS', 'Linux'],
            'tablet': ['iPadOS', 'Android'],
            'smart_tv': ['Tizen', 'WebOS']
        }

    def get_random_event(self):
        """Generates a single production-grade event payload."""
        device = random.choice(self.devices)
        
        # Simulate realistic amount: Checkouts are more expensive than views
        action = random.choice(self.actions)
        if action == 'checkout':
            amount = round(random.uniform(50.0, 1000.0), 2)
        else:
            amount = round(random.uniform(0.0, 50.0), 2)

        return {
            'event_id': str(uuid.uuid4()),
            'event_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
            'user_id': random.randint(10000, 99999),
            'session_id': f"sess_{random.getrandbits(32)}",
            'action': action,
            'device': device,
            'os': random.choice(self.os[device]),
            'product_id': random.randint(1, 5000),
            'amount': amount,
            'version': '2.0' # Helpful for tracking schema evolution
        }

def simulate_latency():
    """Simulates real-world network jitter/latency."""
    # 90% of events are fast, 10% have a slight delay
    if random.random() > 0.9:
        return random.uniform(0.1, 0.5)
    return 0.01