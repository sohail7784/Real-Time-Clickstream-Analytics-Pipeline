#!/bin/bash

# --- Color Codes for Output ---
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🚀 Starting ClickHouse Real-Time Ingestion Program Setup...${NC}"

# 1. Start Infrastructure
echo -e "${GREEN}Step 1: Spinning up Docker containers (Kafka, ClickHouse, Grafana)...${NC}"
docker-compose up -d

# Wait for ClickHouse to be ready
echo "Waiting for ClickHouse to start..."
until docker exec clickhouse-server clickhouse-client --query "SELECT 1" &>/dev/null; do
    sleep 2
done

# 2. Configure Kafka Topic (Chapter 293)
echo -e "${GREEN}Step 2: Configuring Kafka Topics...${NC}"
docker exec clickhouse-streaming-kafka-1 \
  kafka-topics.sh --bootstrap-server localhost:9092 \
  --create --topic web_events \
  --partitions 6 \
  --replication-factor 1 \
  --if-not-exists

# 3. Apply ClickHouse Schemas (Chapters 294-296)
echo -e "${GREEN}Step 3: Applying ClickHouse Tables and Materialized Views...${NC}"

# Create Raw Ingestion Table (Kafka Engine)
docker exec -i clickhouse-server clickhouse-client --multiquery < ./clickhouse/01-tables.sql

# Create Final Storage and MVs
docker exec -i clickhouse-server clickhouse-client --multiquery < ./clickhouse/02-materialized-views.sql

# Create Aggregation Tables
docker exec -i clickhouse-server clickhouse-client --multiquery < ./clickhouse/03-aggregations.sql

# 4. Install Python Dependencies
echo -e "${GREEN}Step 4: Preparing Python Producer...${NC}"
pip install -r ./producers/requirements.txt

# 5. Final Health Check
echo -e "${YELLOW}--- SETUP COMPLETE ---${NC}"
echo -e "Dashboard: http://localhost:3000 (Admin/Admin)"
echo -e "Kafka GUI: http://localhost:8080"
echo -e "ClickHouse Port: 8123"
echo -e ""
echo -e "${GREEN}To start data flow, run: python producers/producer.py${NC}"